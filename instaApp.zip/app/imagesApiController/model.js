module.exports = {
     ImageDatasArray: [
          /*
           {
                "id": 1650365373147,
                "album": "nazwa_albumu",
                "originalName": "input.jpg",
                "url": "uploads\\nazwa_albumu\\upload_c0a688aa9fb20b6a9cd6aea01cd2cbd1.jpg",
                "lastChange": "original",
                "history": [
                     {
                          "status": "original",
                          "timestamp": "2022-04-19T10:49:33.101Z"
                     }
                ]
           }
          */
     ],
     ImagePathsById: { /* ImageData.id: filePath */ }
}