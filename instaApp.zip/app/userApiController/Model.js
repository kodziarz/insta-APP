module.exports = {
    Users: {/* userId: userData */ }
}